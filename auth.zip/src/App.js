import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Signin from './Login/login';
import './App.css';
import Signup from './Registration/registration';
import productComponents from './Product/Product';

function App() {
  return (
    <Router>
      <Routes>
        <Route path='/' element={<Signin />} />
        <Route path='/register' element={<Signup />} />
        <Route path='/dashboard' element={productComponents} />
      </Routes>
    </Router>
  );
}

export default App;
