const productData=[
  {
    "id": 1,
    "name": "Brown eggs",
    "category": "dairy",
    "description": "Farm-fresh treasures: brown eggs, rich in flavor and nutrients.",
    "price": 28.1,
    "image": "https://www.kyheggs.com/image/cache/catalog/product/3-fresh-brown-eggs-large-30s-0002-800x800.jpg",
    "rating": 4.3
  },
  {
    "id": 2,
    "name": "Sweet fresh strawberry",
    "category": "fruit",
    "description": "Juicy bursts of sweetness, embodying summer's essence in each bite",
    "price": 29.45,
    "image": "https://images.freshop.com/2311226/af3195fa13c429464822c30de3848ed4_large.png",
    "rating": 4
  },
  { "id": 3,
    "name": "Organic milk",
    "category": "dairy",
    "description": "Pure, creamy nourishment from conscientiously cared-for cows in organic pastures",
    "price": 3.99,
    "image": "https://i5.walmartimages.com/asr/5897394e-5e49-4b73-b1ea-db4109b58c1b_1.3d9ff69d9fccfe4964f7d2cdac8c2097.jpeg",
    "rating": 5
  },
  {
    
      "id":4,
      "name": "Ripe bananas",
      "category": "fruit",
      "description": "Soft, golden perfection. nature's sweet embrace in each tender bite",
      "price": 1.99,
      "image": "https://i5.walmartimages.com/asr/4394d565-6249-458a-9bce-2d2f3e621674_1.f1a303ce1579fe9d67dcd20a08d15b44.png?odnWidth=1000&odnHeight=1000&odnBg=ffffff",
      "rating": 4
    
  },
  {
    "id":5,
    "name": "Whole grain bread",
    "category": "bakery",
    "description": "Nutrient-packed slices: hearty, wholesome fuel for body and soul.",
    "price": 4.49,
    "image": "https://i5.walmartimages.com/asr/8c0316b1-a706-4490-a211-0ffa0f7e9b64.6728851795984e734bcf8439b19064ab.jpeg?odnWidth=1000&odnHeight=1000&odnBg=ffffff",
    "rating": 4.5
  },
  {
    id: 6,
    "name": "Organic tomatoes",
    "category": "vegetable",
    "description": "Sun-ripened, vibrant orbs bursting with organic garden goodness",
    "price": 2.99,
    "image": "https://images.freshop.com/1564405684711691370/937017e06af7dc57b04b682a036f8004_large.png",
    "rating": 4.2
  },
  
]
export default productData;

